import smtplib, uuid, os
from pymongo import MongoClient
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

# MongoDB Setup
client = MongoClient("mongodb://localhost:27017")
db = client["email_tracker"]
collection = db["emails"]

# Ngrok public URL for tracking
NGROK_URL = "https://56e2-2401-4900-7918-c08a-28fc-575-9076-f1c7.ngrok-free.app"  # Change as needed


# ===============================
# Caesar Cipher Encrypt/Decrypt
# ===============================
def caesar_cipher_encrypt(text, shift=3):
    encrypted = ""
    for char in text:
        if char.isalpha():
            base = ord('A') if char.isupper() else ord('a')
            encrypted += chr((ord(char) - base + shift) % 26 + base)
        else:
            encrypted += char
    return encrypted


def caesar_cipher_decrypt(text, shift=3):
    return caesar_cipher_encrypt(text, -shift)


def decrypt_email(encrypted_email):
    return caesar_cipher_decrypt(encrypted_email)


# ===============================
# Email Template HTML Generator
# ===============================
def render_email_html(content, tracking_id, name, company):
    tracking_url = f"{NGROK_URL}/track/{tracking_id}.png"
    click_url = f"{NGROK_URL}/click/{tracking_id}"

    with open(os.path.join("templates", "email_template.html"), "r", encoding="utf-8") as f:
        html = f.read()

    return html.replace("{{ content }}", content) \
        .replace("{{ name }}", name) \
        .replace("{{ company }}", company) \
        .replace("{{ tracking_url }}", tracking_url) \
        .replace("{{ click_url }}", click_url)


# ===============================
# Send Batch Emails
# ===============================
def send_batch_emails(subject, content, sender_email, sender_pass, batch_size, recipients_df):
    batch_df = recipients_df.head(batch_size)  # Top N emails only

    for _, row in batch_df.iterrows():
        recipient = row['email']
        name = row['name']
        company = row['company']
        tracking_id = str(uuid.uuid4())

        # Generate personalized HTML email
        html_content = render_email_html(content, tracking_id, name, company)

        # Create Email
        msg = MIMEMultipart()
        msg["From"] = sender_email
        msg["To"] = recipient
        msg["Subject"] = subject
        msg.attach(MIMEText(html_content, "html"))

        # Send Email
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
            server.login(sender_email, sender_pass)
            server.sendmail(sender_email, recipient, msg.as_string())

        # Store encrypted email in DB
        encrypted_email = caesar_cipher_encrypt(recipient)

        collection.insert_one({
            "email": encrypted_email,
            "subject": subject,
            "tracking_id": tracking_id,
            "opened": False,
            "clicked": False
        })


# ===============================
# Get Email Tracking Data (Decrypted)
# ===============================
def get_tracking_data():
    emails = list(collection.find())

    for email in emails:
        try:
            email["email"] = decrypt_email(email["email"])
        except:
            pass  # if decryption fails, keep it encrypted

    return emails


# ===============================
# Campaign Analytics
# ===============================
def get_campaign_analytics():
    total = collection.count_documents({})
    opened = collection.count_documents({"opened": True})
    clicked = collection.count_documents({"clicked": True})
    hot = collection.count_documents({"opened": True, "clicked": True})
    cold = collection.count_documents({"opened": False, "clicked": False})

    return {
        "Total Emails Sent": total,
        "Opened": opened,
        "Clicked": clicked,
        "Hot Leads": hot,
        "Cold Leads": cold,
        "Open Rate (%)": round((opened / total) * 100, 2) if total else 0,
        "Click Rate (%)": round((clicked / total) * 100, 2) if total else 0
    }
