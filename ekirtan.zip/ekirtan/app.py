import pandas as pd
from flask import Flask, render_template, request, redirect, url_for, send_file
from email_utils import send_batch_emails, get_tracking_data, decrypt_email
from pymongo import MongoClient
import os
import webbrowser
import threading
from io import BytesIO

app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = "uploads"

client = MongoClient("mongodb://localhost:27017")
db = client["email_tracker"]
collection = db["emails"]

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/status")
def status():
    emails = get_tracking_data()
    return render_template("status.html", emails=emails)

@app.route("/send", methods=["POST"])
def send():
    data = request.form
    sender_email = data["sender_email"]
    sender_pass = data["sender_pass"]
    batch_size = int(data["batch_size"])

    df = pd.read_excel("recipients.xlsx")

    subject = "Discover How We Can Help You Grow 🚀"
    content = "Hey {{ name }}, we noticed that {{ company }} might benefit from our services!"

    send_batch_emails(subject, content, sender_email, sender_pass, batch_size, df)

    for i in range(len(df)):
        email = df.loc[i, "email"]
        collection.update_one({"email": email}, {
            "$set": {
                "status": "Sent",
                "clicked": False  # ✅ Ensure clicked is False initially
            }
        }, upsert=True)

    return render_template("success.html")

@app.route("/click/<tracking_id>")
def click(tracking_id):
    collection.update_one({"tracking_id": tracking_id}, {
        "$set": {
            "status": "Clicked",
            "clicked": True  # ✅ Add this line
        }
    })
    return "Thank you for clicking the link!"


@app.route("/track/<tracking_id>")
def track(tracking_id):
    try:
        collection.update_one({"tracking_id": tracking_id}, {"$set": {"status": "Opened"}})
        # Return a 1x1 transparent pixel
        pixel = BytesIO()
        pixel.write(
            b'\x47\x49\x46\x38\x39\x61\x01\x00\x01\x00\x80\x00\x00\x00\x00\x00\xFF\xFF\xFF'
            b'\x21\xF9\x04\x01\x00\x00\x00\x00\x2C\x00\x00\x00\x00\x01\x00\x01\x00\x00\x02'
            b'\x02\x4C\x01\x00\x3B'
        )
        pixel.seek(0)
        return send_file(pixel, mimetype='image/gif')
    except Exception as e:
        return f"Error: {str(e)}"

@app.route('/analytics')
def analytics():
    emails = list(collection.find())
    total_sent = sum(1 for email in emails if email.get('status') in ['Sent', 'Clicked', 'Opened'])
    clicked = sum(1 for email in emails if email.get('status') == 'Clicked')
    hot_leads = clicked
    cold_leads = total_sent - clicked
    click_rate = round((clicked / total_sent) * 100, 2) if total_sent > 0 else 0

    return render_template('analytics.html',
                           total_sent=total_sent,
                           total_clicked=clicked,
                           hot_leads=hot_leads,
                           cold_leads=cold_leads,
                           click_rate=click_rate)

def open_browser():
    webbrowser.open_new("http://127.0.0.1:5000/")

if __name__ == '__main__':
    threading.Timer(1.5, open_browser).start()
    app.run(debug=True)